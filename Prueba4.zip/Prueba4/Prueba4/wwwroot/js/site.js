﻿// Please see documentation at https://docs.microsoft.com/aspnet/core/client-side/bundling-and-minification
// for details on configuring this project to bundle and minify static web assets.

// Write your JavaScript code.
// Realizar una solicitud GET a la API para obtener los productos
fetch('api/productos')
    .then(response => response.json())
    .then(data => mostrarProductos(data))
    .catch(error => console.error('Error:', error));

function mostrarProductos(productos) {
    const productosContainer = document.getElementById('productos-container');

    // Limpiar el contenedor de productos
    productosContainer.innerHTML = '';

    // Recorrer la lista de productos y mostrarlos en el contenedor
    productos.forEach(producto => {
        const productoDiv = document.createElement('div');
        productoDiv.innerHTML = `
                    <h3>ID: ${producto.id}</h3>
                    <p>Nombre: ${producto.nombre}</p>
                    <p>Descripción: ${producto.descripcion}</p>
                    <p>Precio: ${producto.precio}</p>
                    <hr>
                `;
        productosContainer.appendChild(productoDiv);
    });
}