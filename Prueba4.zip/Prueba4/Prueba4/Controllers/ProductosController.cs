﻿using Microsoft.AspNetCore.Mvc;
using Prueba4.Models;
using System;
using System.Collections.Generic;

namespace TuProyecto.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class ProductosController : ControllerBase
    {
        [HttpGet]
        public ActionResult<IEnumerable<Producto>> ObtenerProductos()
        {
            // Aquí se podría acceder a una base de datos o a otra fuente de datos
            // para obtener la lista de productos
            List<Producto> productos = ObtenerProductosDesdeBaseDeDatos();

            // Devolver los productos como respuesta
            return Ok(productos);
        }

        // Otros métodos de acción para realizar operaciones CRUD en los productos
        // ...

        // Método auxiliar para obtener los productos desde una base de datos (ejemplo)
        private List<Producto> ObtenerProductosDesdeBaseDeDatos()
        {
            // Aquí iría la lógica para acceder a la base de datos y obtener los productos
            // Por ahora, utilizaremos datos de ejemplo
            List<Producto> productos = new List<Producto>
            {
                new Producto { Id = 1, Nombre = "Producto 1", Precio = 10.99m, Descripcion = "Descripción del producto 1" },
                new Producto { Id = 2, Nombre = "Producto 2", Precio = 19.99m, Descripcion = "Descripción del producto 2" },
                new Producto { Id = 3, Nombre = "Producto 3", Precio = 5.99m, Descripcion = "Descripción del producto 3" }
            };

            return productos;
        }
    }
}
