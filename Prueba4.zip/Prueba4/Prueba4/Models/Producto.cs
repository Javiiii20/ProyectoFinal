﻿namespace Prueba4.Models
{
    public class Producto
    {
        public int Id { get; set; }
        public string Nombre { get; set; }
        public decimal Precio { get; set; }
        public string Descripcion { get; set; }
        // Otros campos relevantes para tu producto

        // Puedes agregar métodos adicionales según tus necesidades
    }

}
