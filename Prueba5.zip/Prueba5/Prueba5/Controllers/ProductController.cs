﻿using Microsoft.AspNetCore.Mvc;
using Prueba5.Models.DB;
using System.Collections.Generic;
using System.Linq;

namespace Prueba5.Controllers
{
    [ApiController]
    [Route("api/products")]
    public class ProductController : ControllerBase
    {
        private readonly MasterContext _db;

        public ProductController(MasterContext db)
        {
            _db = db;
        }

        [HttpGet]
        public ActionResult<IEnumerable<Product>> GetProducts()
        {
            var products = _db.Products.ToList();
            return Ok(products);
        }
    }
}

