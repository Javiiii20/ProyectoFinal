﻿using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Mvc;
using Prueba3.Models;
using System.Collections.Generic;

namespace Prueba3.Controllers
{
    [ApiController]
    [Route("productos")]
    public class ProductosController : ControllerBase
    {
        private static List<Producto> _productos = new List<Producto>
        {
            new Producto { Id = 1, Nombre = "Producto 1", Descripcion = "Descripción del producto 1", Precio = 99.99m },
            new Producto { Id = 2, Nombre = "Producto 2", Descripcion = "Descripción del producto 2", Precio = 199.99m }
        };

        [HttpGet]
        [Route("obtener")]
        public IEnumerable<Producto> ObtenerProductos()
        {
            return _productos;
        }
    }
}
